from pathlib import Path

import pytest

from sweettooth_final.installer import install, startup_directory


def test_resolves_pymol_root(tmp_path: Path):
    expected = tmp_path / "data" / "startup"
    expected.mkdir(parents=True)
    assert startup_directory(tmp_path) == expected


def test_installs_self_contained_plugin(tmp_path: Path):
    destination = install(tmp_path)
    text = destination.read_text(encoding="utf-8")
    assert destination == tmp_path / "data" / "startup" / "sweettooth_final.py"
    assert "sweet_load" in text
    assert "sweettooth_reset" in text


def test_refuses_overwrite_without_force(tmp_path: Path):
    install(tmp_path)
    with pytest.raises(FileExistsError):
        install(tmp_path)
    assert install(tmp_path, force=True).is_file()


def test_runtime_compatibility_module_is_packaged():
    from sweettooth_final.runtime import imp

    assert callable(imp.find_module)


def test_launcher_loads_the_packaged_plugin():
    from sweettooth_final import launcher

    assert launcher.Path(launcher.__file__).parent.joinpath("plugin.py").is_file()
