import ast
from pathlib import Path


PLUGIN = Path(__file__).parents[1] / "src" / "sweettooth_final" / "plugin.py"


def test_plugin_compiles_and_registers_core_commands():
    source = PLUGIN.read_text(encoding="utf-8")
    ast.parse(source)
    for command in ("sweet_load", "sweettooth_load", "sweettooth",
                    "sweet_load_md", "sweet_load_md_pdb",
                    "sweettooth_residue", "sweettooth_status", "sweettooth_reset"):
        assert command in source


def test_no_artifact_geometry_or_legend():
    source = PLUGIN.read_text(encoding="utf-8")
    for forbidden in ("CYLINDER", "load_cgo", "WHITE_SWIRLS", "GUMMY_GLOSS",
                      "sweettooth_legend", "pseudoatom", "ribbon_smooth",
                      "H_LIGHT", "H_DARK", "WAFER_LIGHT", "WAFER_DARK"):
        assert forbidden not in source


def test_no_automatic_image_generation():
    source = PLUGIN.read_text(encoding="utf-8")
    assert "cmd.png" not in source
    assert "cmd.ray" not in source
