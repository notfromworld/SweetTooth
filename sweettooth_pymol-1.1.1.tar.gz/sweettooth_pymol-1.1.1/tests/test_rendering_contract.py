import importlib.util
import sys
import types
from pathlib import Path


PLUGIN = Path(__file__).parents[1] / "src" / "sweettooth_final" / "plugin.py"


class FakeCmd:
    """Strict PyMOL-like command surface used for renderer regression tests."""

    def __init__(self):
        self.calls = []

    def _call(self, name, *args, **kwargs):
        self.calls.append((name, args, kwargs))

    def extend(self, *args, **kwargs): self._call("extend", *args, **kwargs)
    def bg_color(self, *args, **kwargs): self._call("bg_color", *args, **kwargs)
    def delete(self, *args, **kwargs): self._call("delete", *args, **kwargs)
    def hide(self, *args, **kwargs): self._call("hide", *args, **kwargs)
    def create(self, *args, **kwargs): self._call("create", *args, **kwargs)
    def show(self, *args, **kwargs): self._call("show", *args, **kwargs)
    def set_color(self, *args, **kwargs): self._call("set_color", *args, **kwargs)
    def color(self, *args, **kwargs): self._call("color", *args, **kwargs)
    def alter(self, *args, **kwargs): self._call("alter", *args, **kwargs)
    def rebuild(self, *args, **kwargs): self._call("rebuild", *args, **kwargs)

    def set(self, *args, **kwargs):
        self._call("set", *args, **kwargs)


def load_plugin():
    fake_cmd = FakeCmd()
    pymol = types.ModuleType("pymol")
    pymol.cmd = fake_cmd
    old_pymol = sys.modules.get("pymol")
    old_module = sys.modules.get("sweettooth_render_test_plugin")
    sys.modules["pymol"] = pymol
    try:
        spec = importlib.util.spec_from_file_location("sweettooth_render_test_plugin", PLUGIN)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
    finally:
        if old_pymol is None:
            sys.modules.pop("pymol", None)
        else:
            sys.modules["pymol"] = old_pymol
        if old_module is None:
            sys.modules.pop("sweettooth_render_test_plugin", None)
        else:
            sys.modules["sweettooth_render_test_plugin"] = old_module
    return module, fake_cmd


def record(resi, state, index=None):
    return {
        "chain": "A", "resi": resi, "icode": "", "aa": "A",
        "sequence_index": index or resi, "state": state, "source_line": 1,
        "dssp_index": (index or resi) - 1,
    }


def test_clean_modern_cartoon_render_uses_single_view_copy():
    plugin, fake = load_plugin()
    plugin.OBJECT = "protein"
    plugin.MAPPED = [
        record(1, "H"), record(2, "G"), record(3, "I"),
        record(4, "E"), record(5, "B"), record(6, "C"),
        record(7, "S"), record(8, "T"), record(9, "P"),
    ]

    plugin._render()

    assert ("create", ("STF_VIEW", "protein"), {}) in fake.calls
    assert not any(name == "create" and args[0] != "STF_VIEW" for name, args, _ in fake.calls)

    setting_calls = [call for call in fake.calls if call[0] == "set"]
    assert any(args[:2] == ("cartoon_cylindrical_helices", 0) and args[2] == "STF_VIEW"
               for _, args, _ in setting_calls)
    assert any(args[:2] == ("cartoon_fancy_helices", 1) and args[2] == "STF_VIEW"
               for _, args, _ in setting_calls)

    alter_calls = [args for name, args, _ in fake.calls if name == "alter"]
    assert alter_calls
    assert any("ss='H'" in args[1] for args in alter_calls)
    assert any("ss='S'" in args[1] for args in alter_calls)
    assert any("ss='L'" in args[1] for args in alter_calls)
    assert all("STF_VIEW" in args[0] for args in alter_calls)
    assert all("protein" not in args[0] for args in alter_calls)

    colors = [args for name, args, _ in fake.calls if name == "color"]
    assert any(args[0] == "STF_COLOR_H" for args in colors)
    assert any(args[0] == "STF_COLOR_E" for args in colors)
    assert any(args[0] == "STF_COLOR_C" for args in colors)
    assert any(args[0] == "STF_CANDY_WHITE" for args in colors)


def test_helix_stripes_are_dense_and_helix_only():
    plugin, _ = load_plugin()
    records = [record(i, "H", i) for i in range(1, 10)] + [record(10, "C", 10)]
    stripes = plugin._helix_stripe_records(records)
    stripe_resi = [entry["resi"] for entry in stripes]
    assert stripe_resi == [1, 4, 7]
    assert all(item["state"] in plugin.HELIX_STATES for item in stripes)


def test_md_movie_commands_update_geometry_and_colors_without_extra_objects():
    plugin, _ = load_plugin()
    plugin.MAPPED = [
        record(1, "C", 1), record(2, "C", 2), record(3, "C", 3),
        record(4, "C", 4), record(5, "C", 5),
    ]
    command = plugin._md_movie_commands(["H", "G", "E", "S", "P"], "STF_VIEW")

    assert "alter ((STF_VIEW) and chain A and resi 1+2), ss='H'" in command
    assert "alter ((STF_VIEW) and chain A and resi 3), ss='S'" in command
    assert "alter ((STF_VIEW) and chain A and resi 4+5), ss='L'" in command
    assert "rebuild STF_VIEW" in command
    assert "color STF_CANDY_WHITE" in command
    assert "ribbon_smooth" not in command
