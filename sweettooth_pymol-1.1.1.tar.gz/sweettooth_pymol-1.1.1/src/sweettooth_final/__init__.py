"""SweetTooth Final package metadata (PyMOL is loaded only by the plugin)."""

__version__ = "1.1.1"

