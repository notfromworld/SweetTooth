"""Runtime compatibility modules used only by the package launcher."""

