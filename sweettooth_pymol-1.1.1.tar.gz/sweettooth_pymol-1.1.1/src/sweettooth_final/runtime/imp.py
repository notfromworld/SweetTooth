"""Small Python 3.12 replacement for the legacy ``imp.find_module`` call."""

import importlib.util


def find_module(name, path=None):
    spec = importlib.util.find_spec(name, path)
    if spec is None:
        raise ImportError(name)
    locations = spec.submodule_search_locations
    location = next(iter(locations)) if locations else spec.origin
    return (None, location, None)

