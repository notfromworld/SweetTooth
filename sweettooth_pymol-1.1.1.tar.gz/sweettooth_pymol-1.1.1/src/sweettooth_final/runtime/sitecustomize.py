"""Compatibility for a float slider value in the bundled PyMOL lighting GUI."""

try:
    from PyQt5 import QtWidgets

    slider = QtWidgets.QSlider
    if not getattr(slider, "_sweettooth_integer_patch", False):
        for method_name in ("setMinimum", "setMaximum", "setValue"):
            original = getattr(slider, method_name)

            def integer_method(self, value, _original=original):
                return _original(self, int(round(float(value))))

            setattr(slider, method_name, integer_method)
        slider._sweettooth_integer_patch = True
except Exception:
    pass
