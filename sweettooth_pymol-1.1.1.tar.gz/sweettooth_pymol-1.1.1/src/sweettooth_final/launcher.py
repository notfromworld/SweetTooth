"""Launch the Debian/Ubuntu PyMOL build without relying on an activated shell."""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
from typing import List, Optional


def _system_python() -> str:
    for candidate in ("/usr/bin/python3.12", "/usr/bin/python3"):
        if Path(candidate).is_file():
            return candidate
    raise RuntimeError("system Python was not found; install the system PyMOL package first")


def main(argv: Optional[List[str]] = None) -> int:
    """Start PyMOL with the compatibility module needed by PyMOL 2.5."""
    arguments = list(sys.argv[1:] if argv is None else argv)
    runtime = str(Path(__file__).resolve().parent / "runtime")
    environment = os.environ.copy()
    environment["PYTHONPATH"] = runtime + os.pathsep + environment.get("PYTHONPATH", "")
    environment.setdefault("PYMOL_PATH", "/usr/share/pymol")
    environment.setdefault("PYMOL_DATA", "/usr/share/pymol/data")
    environment.setdefault("PYMOL_SCRIPTS", "/usr/share/pymol/scripts")
    environment.setdefault("CHEMPY_DATA", "/usr/share/pymol/data/chempy")
    plugin = str(Path(__file__).resolve().parent / "plugin.py")
    try:
        return subprocess.run([_system_python(), "-m", "pymol.__init__",
                               "-d", "run " + plugin] + arguments,
                              env=environment, check=False).returncode
    except OSError as error:
        print("SweetTooth could not start system PyMOL: %s" % error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
