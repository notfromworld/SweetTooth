"""Install the self-contained SweetTooth plugin into a chosen PyMOL tree."""

from __future__ import annotations

import argparse
from pathlib import Path
import pkgutil
import shutil
from typing import List, Optional, Union


def startup_directory(pymol_path: Union[str, Path]) -> Path:
    root = Path(pymol_path).expanduser().resolve()
    if root.name == "startup":
        return root
    if (root / "data" / "startup").is_dir():
        return root / "data" / "startup"
    if (root / "startup").is_dir():
        return root / "startup"
    return root / "data" / "startup"


def install(pymol_path: Union[str, Path], *, force: bool = False) -> Path:
    destination_dir = startup_directory(pymol_path)
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / "sweettooth_final.py"
    if destination.exists() and not force:
        raise FileExistsError(
            f"{destination} already exists; rerun with --force to replace this SweetTooth plugin"
        )
    payload = pkgutil.get_data("sweettooth_final", "plugin.py")
    if payload is None:
        raise OSError("packaged SweetTooth plugin resource is missing")
    destination.write_bytes(payload)
    return destination


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Install SweetTooth Final into a specified PyMOL installation."
    )
    parser.add_argument("--pymol-path", required=True, help="PyMOL root or startup directory")
    parser.add_argument("--force", action="store_true", help="replace an older SweetTooth plugin")
    arguments = parser.parse_args(argv)
    try:
        destination = install(arguments.pymol_path, force=arguments.force)
    except (OSError, FileExistsError) as error:
        parser.error(str(error))
    print(f"SweetTooth Final installed at: {destination}")
    print("Restart PyMOL, then run: sweet_load /absolute/path/to/structure.pdb")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
