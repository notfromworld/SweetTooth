# -*- coding: utf-8 -*-
"""SweetTooth Final: interactive DSSP visualization for PyMOL 2.5+.

This is a single-file, user-installable PyMOL plugin. It visualizes DSSP
secondary-structure assignments, never modifies source annotation files, and
never saves images automatically.
"""
from __future__ import print_function

import os
import re
import shutil
import subprocess
import tempfile
from pymol import cmd


def _patch_qt_slider_integer_api():
    """Keep older PyMOL lighting plugins working with strict modern PyQt."""
    try:
        from pymol.Qt import QtWidgets
        slider = QtWidgets.QSlider
        if getattr(slider, '_sweettooth_integer_patch', False):
            return
        for method_name in ('setMinimum', 'setMaximum', 'setValue'):
            original = getattr(slider, method_name)
            def integer_method(self, value, _original=original):
                return _original(self, int(round(float(value))))
            setattr(slider, method_name, integer_method)
        slider._sweettooth_integer_patch = True
    except Exception:
        pass


_patch_qt_slider_integer_api()

PREFIX = 'STF_'
STATES = ('H', 'B', 'E', 'G', 'I', 'P', 'T', 'S', 'C')
HELIX_STATES = ('H', 'G', 'I')
SHEET_STATES = ('E', 'B')
LOOP_STATES = ('C', 'S', 'T', 'P')
STATE_NAMES = {
    'H': 'alpha helix / candy cane',
    'G': '3-10 helix / candy cane',
    'I': 'pi helix / candy cane',
    'E': 'extended strand / chocolate wafer',
    'B': 'beta bridge / chocolate wafer',
    'C': 'coil / gummy worm',
    'S': 'bend / marshmallow rope',
    'T': 'turn / soft pretzel',
    'P': 'PPII / licorice twist',
}
STATE_COLORS = {
    'H': (0.88, 0.10, 0.08),
    'G': (0.88, 0.10, 0.08),
    'I': (0.88, 0.10, 0.08),
    'E': (0.31, 0.16, 0.05),
    'B': (0.31, 0.16, 0.05),
    'C': (0.08, 0.73, 0.34),
    'S': (0.90, 0.98, 1.00),
    'T': (0.72, 0.47, 0.18),
    'P': (0.09, 0.09, 0.11),
}
ACCENT_COLORS = {
    'CANDY_WHITE': (0.99, 0.99, 0.97),
}
THREE_TO_ONE = {
    'ALA':'A','ARG':'R','ASN':'N','ASP':'D','CYS':'C','GLN':'Q','GLU':'E',
    'GLY':'G','HIS':'H','ILE':'I','LEU':'L','LYS':'K','MET':'M','PHE':'F',
    'PRO':'P','SER':'S','THR':'T','TRP':'W','TYR':'Y','VAL':'V','MSE':'M','SEC':'U'
}

DATASET = []
SOURCE = None
OBJECT = None
MAPPED = []
MD_DSSP_FRAMES = []
MD_STRIDE = 1


def _message(level, text):
    print('[SweetTooth Final %s] %s' % (level, text))



def _parse_resi(value):
    value = str(value).strip(); number = ''; insertion = ''
    for character in value:
        if character.isdigit() or (character == '-' and not number):
            number += character
        else:
            insertion += character
    return int(number), insertion


def _read_dssp(path):
    """Read classic mkdssp/DSSP fixed-width output without model inference."""
    records = []; in_table = False
    handle = open(path, 'r')
    try:
        for line_number, line in enumerate(handle, 1):
            if '#  RESIDUE AA STRUCTURE' in line:
                in_table = True; continue
            if not in_table or len(line) < 17:
                continue
            amino_acid = line[13:14]
            if amino_acid == '!':
                continue
            residue_text = line[5:10].strip()
            if not residue_text:
                continue
            try:
                residue_number = int(residue_text)
            except ValueError:
                continue
            insertion = line[10:11].strip()
            chain = line[11:12].strip()
            state = line[16:17].strip().upper()
            if state not in STATES:
                state = 'C'
            if amino_acid.islower():
                amino_acid = 'C'
            amino_acid = amino_acid.upper()
            records.append({'chain': chain, 'resi': residue_number, 'icode': insertion,
                            'aa': amino_acid, 'sequence_index': len(records) + 1,
                            'state': state, 'source_line': line_number})
    finally:
        handle.close()
    if not in_table:
        raise ValueError('not a classic DSSP file: table header was not found')
    if not records:
        raise ValueError('DSSP file contains no residue assignments')
    return records


def _run_mkdssp(structure_path):
    """Generate raw DSSP assignments in a temporary directory and parse them."""
    executable = shutil.which('mkdssp') or shutil.which('dssp')
    if not executable:
        raise ValueError('mkdssp was not found on PATH; install DSSP or load an existing .dssp file')
    temporary = tempfile.mkdtemp(prefix='sweettooth_dssp_')
    try:
        input_path = structure_path
        extension = os.path.splitext(structure_path)[1].lower()
        if extension in ('.pdb', '.ent'):
            with open(structure_path, 'r') as source:
                contents = source.read()
            first = next((line for line in contents.splitlines() if line.strip()), '')
            if not first.startswith('HEADER'):
                input_path = os.path.join(temporary, 'input.pdb')
                with open(input_path, 'w') as generated:
                    generated.write('HEADER    SWEETTOOTH TEMPORARY DSSP INPUT\n')
                    generated.write(contents)
        output_path = os.path.join(temporary, 'assignments.dssp')
        process = subprocess.run([executable, '--output-format', 'dssp', input_path, output_path],
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 universal_newlines=True)
        if process.returncode != 0:
            detail = (process.stderr or process.stdout or 'unknown mkdssp error').strip()
            raise ValueError('mkdssp failed: ' + detail)
        records = _read_dssp(output_path)
        _message('INFO', 'mkdssp generated %d raw assignments from %s' % (len(records), structure_path))
        return records
    finally:
        shutil.rmtree(temporary, ignore_errors=True)


def sweettooth_load(path, mode='dssp'):
    """Load DSSP data or generate DSSP from a supported structure file."""
    global DATASET, SOURCE
    mode = str(mode).strip().strip('"').strip("'").lower()
    path = str(path).strip().strip('"').strip("'")
    path = os.path.abspath(os.path.expanduser(path))
    if mode != 'dssp':
        _message('ERROR', 'SweetTooth Final currently accepts DSSP data only')
        return
    if not os.path.isfile(path):
        _message('ERROR', 'file does not exist: ' + path)
        return
    try:
        extension = os.path.splitext(path)[1].lower()
        if extension in ('.pdb', '.ent', '.cif', '.mmcif'):
            records = _run_mkdssp(path)
        else:
            records = _read_dssp(path)
    except Exception as error:
        _message('ERROR', 'could not load DSSP data: %s' % error)
        return
    DATASET = records
    SOURCE = path
    _message('INFO', 'loaded %d DSSP residue records from %s' % (len(records), path))


def _structure_map(object_name):
    atoms = []
    cmd.iterate('(%s) and polymer.protein and name CA' % object_name,
                'atoms.append((chain,resi,resn))', space={'atoms': atoms})
    mapping = {}
    for chain, resi, resn in atoms:
        try:
            number, insertion = _parse_resi(resi)
            mapping[(str(chain), number, insertion)] = THREE_TO_ONE.get(str(resn).upper(), 'X')
        except Exception:
            pass
    return mapping


def _selection(record, object_name=None):
    target = object_name or OBJECT
    chain = (' and chain %s' % record['chain']) if record['chain'] else ''
    return '(%s)%s and resi %d%s' % (target, chain, record['resi'], record['icode'])


def _records_selection(records, object_name):
    if not records:
        return ''
    by_chain = {}
    for record in records:
        chain = record['chain']
        by_chain.setdefault(chain, []).append('%d%s' % (record['resi'], record['icode']))
    parts = []
    for chain in sorted(by_chain):
        chain_part = (' and chain %s' % chain) if chain else ''
        parts.append('((%s)%s and resi %s)' % (object_name, chain_part, '+'.join(by_chain[chain])))
    return ' or '.join(parts)


def _records_for_states(records, states):
    return [record for record in records if record['state'] in states]


def _helix_stripe_records(records):
    stripes = []
    run_index = 0
    previous = None
    for record in records:
        current = (record['chain'], record['resi'], record['icode'])
        if record['state'] not in HELIX_STATES:
            previous = None
            run_index = 0
            continue
        contiguous = False
        if previous is not None and previous[0] == current[0] and not previous[2] and not current[2]:
            contiguous = (current[1] == previous[1] + 1)
        if previous is None or not contiguous:
            run_index = 1
        else:
            run_index += 1
        if run_index % 3 == 1:
            stripes.append(record)
        previous = current
    return stripes


def _state_ss_code(state):
    if state in HELIX_STATES:
        return 'H'
    if state in SHEET_STATES:
        return 'S'
    return 'L'


def _read_gmx_dssp(path, object_name):
    """Read GROMACS ``gmx dssp -o`` rows, validating their residue alignment."""
    rows = []
    with open(path, 'r') as handle:
        for line_number, line in enumerate(handle, 1):
            value = line.strip()
            if not value or value.startswith(('#', '@')):
                continue
            states = [('C' if symbol in ('~', '=') else symbol) for symbol in value]
            if any(symbol not in STATES for symbol in states):
                raise ValueError('unsupported DSSP symbol at line %d in %s' % (line_number, path))
            rows.append(states)
    residues = []
    cmd.iterate('(%s) and polymer.protein and name CA' % object_name,
                'residues.append((chain,resi,resn))', space={'residues': residues})
    if not rows:
        raise ValueError('GROMACS DSSP file contains no frame assignments')
    if not residues:
        raise ValueError('the GRO object contains no polymer-protein CA atoms')
    width = len(rows[0])
    if any(len(row) != width for row in rows):
        raise ValueError('GROMACS DSSP rows do not have a consistent width')
    if width == len(residues) - 1:
        residues = residues[1:]
        _message('WARNING', 'GROMACS DSSP omitted one N-terminal residue; mapped rows to residues 2 onward')
    elif width != len(residues):
        raise ValueError('DSSP width %d does not match protein CA residues %d' % (width, len(residues)))
    records = []
    for index, (chain, resi, resn) in enumerate(residues):
        number, insertion = _parse_resi(resi)
        state = rows[0][index]
        records.append({'chain': str(chain), 'resi': number, 'icode': insertion,
                        'aa': THREE_TO_ONE.get(str(resn).upper(), 'X'), 'sequence_index': index + 1,
                        'dssp_index': index, 'state': state, 'source_line': 1})
    return records, rows


def _map_active(force=False):
    global MAPPED
    records = DATASET
    structure = _structure_map(OBJECT); mapped = []; missing = 0; mismatches = 0
    for record in records:
        key = (record['chain'], record['resi'], record['icode'])
        observed = structure.get(key)
        if observed is None:
            missing += 1; continue
        if observed != record['aa'] and not force:
            mismatches += 1; continue
        mapped.append(record)
    MAPPED = mapped
    _message('INFO', 'mapped=%d missing=%d amino-acid-mismatch=%d' % (len(mapped), missing, mismatches))


def _material_transparency(state):
    if state == 'C':
        return 0.22
    if state == 'S':
        return 0.14
    return 0.0


def _apply_ss_geometry(records, object_name):
    for ss_code, state_group in (('H', HELIX_STATES), ('S', SHEET_STATES), ('L', LOOP_STATES)):
        selection = _records_selection(_records_for_states(records, state_group), object_name)
        if selection:
            cmd.alter(selection, "ss='%s'" % ss_code)


def _apply_state_colors(records, object_name):
    for state in STATES:
        selection = _records_selection(_records_for_states(records, (state,)), object_name)
        if selection:
            cmd.color(PREFIX + 'COLOR_' + state, selection)
            cmd.set('cartoon_transparency', _material_transparency(state), selection)
    stripe_selection = _records_selection(_helix_stripe_records(records), object_name)
    if stripe_selection:
        cmd.color(PREFIX + 'CANDY_WHITE', stripe_selection)


def _render():
    cmd.delete(PREFIX + 'VIEW*')
    if not OBJECT or not MAPPED:
        return
    source_view = PREFIX + 'VIEW'
    cmd.hide('cartoon', OBJECT)
    cmd.create(source_view, OBJECT)
    cmd.show('cartoon', source_view)
    cmd.set('cartoon_cylindrical_helices', 0, source_view)
    cmd.set('cartoon_fancy_helices', 1, source_view)
    cmd.set('cartoon_sampling', 14, source_view)
    cmd.set('cartoon_loop_quality', 12, source_view)
    cmd.set('cartoon_oval_quality', 12, source_view)
    cmd.set('cartoon_tube_radius', 0.35, source_view)
    cmd.set('specular', 0.72)
    cmd.set('shininess', 82)
    cmd.set('reflect', 0.22)
    for name, rgb in ACCENT_COLORS.items():
        cmd.set_color(PREFIX + name, rgb)
    for state, rgb in STATE_COLORS.items():
        cmd.set_color(PREFIX + 'COLOR_' + state, rgb)
    _apply_ss_geometry(MAPPED, source_view)
    _apply_state_colors(MAPPED, source_view)
    cmd.rebuild(source_view)
    _message('INFO', 'interactive DSSP view ready; no image was generated')


def _frame_records(frame_states):
    framed = []
    for record in MAPPED:
        index = record.get('dssp_index', record['sequence_index'] - 1)
        if index >= len(frame_states):
            continue
        updated = dict(record)
        updated['state'] = frame_states[index]
        framed.append(updated)
    return framed


def _movie_color_commands(records, object_name):
    commands = []
    for state in STATES:
        selection = _records_selection(_records_for_states(records, (state,)), object_name)
        if selection:
            commands.append('color %sCOLOR_%s, %s' % (PREFIX, state, selection))
            commands.append('set cartoon_transparency, %.3f, %s' % (_material_transparency(state), selection))
    stripe_selection = _records_selection(_helix_stripe_records(records), object_name)
    if stripe_selection:
        commands.append('color %sCANDY_WHITE, %s' % (PREFIX, stripe_selection))
    return commands


def _movie_ss_commands(records, object_name):
    commands = []
    for ss_code, state_group in (('H', HELIX_STATES), ('S', SHEET_STATES), ('L', LOOP_STATES)):
        selection = _records_selection(_records_for_states(records, state_group), object_name)
        if selection:
            commands.append("alter %s, ss='%s'" % (selection, ss_code))
    commands.append('rebuild %s' % object_name)
    return commands


def _md_movie_commands(frame_states, object_name):
    records = _frame_records(frame_states)
    return '; '.join(_movie_ss_commands(records, object_name) + _movie_color_commands(records, object_name))


def _configure_md_movie():
    if not MD_DSSP_FRAMES or not OBJECT:
        return
    view = PREFIX + 'VIEW'
    count = min(len(MD_DSSP_FRAMES), cmd.count_states(view))
    if not count:
        raise ValueError('trajectory created no PyMOL states')
    cmd.mset('1 -%d' % count)
    for frame_number, states in enumerate(MD_DSSP_FRAMES[:count], 1):
        cmd.mdo(frame_number, _md_movie_commands(states, view))
    cmd.frame(1)
    _message('INFO', 'configured %d frame-wise DSSP movie states; use play or mplay' % count)


def _first_protein_object():
    for name in cmd.get_names('objects'):
        if not name.startswith(PREFIX) and cmd.count_atoms('(%s) and polymer.protein' % name):
            return name
    return None


def sweet_load(path, object_name='', mode='auto'):
    """One-command loader: structure -> mkdssp -> mapping -> interactive view."""
    path = str(path).strip().strip('"').strip("'")
    object_name = str(object_name).strip().strip('"').strip("'")
    mode = str(mode).strip().strip('"').strip("'").lower()
    if mode not in ('auto', 'dssp'):
        _message('ERROR', 'SweetTooth Final currently accepts DSSP data only')
        return
    absolute = os.path.abspath(os.path.expanduser(path))
    extension = os.path.splitext(absolute)[1].lower()
    structures = ('.pdb', '.ent', '.cif', '.mmcif', '.gro')
    if extension == '.gro':
        _message('ERROR', 'GRO supports frame-wise DSSP: run gmx dssp, then use sweet_load_md gro, xtc, dssp.dat')
        return
    if extension in structures:
        if not object_name:
            object_name = re.sub(r'[^A-Za-z0-9_]+', '_', os.path.splitext(os.path.basename(absolute))[0])
        if object_name not in cmd.get_names('objects'):
            cmd.load(absolute, object_name)
    elif not object_name:
        object_name = _first_protein_object() or ''
    sweettooth_load(absolute, 'dssp')
    if not DATASET:
        return
    if object_name:
        sweettooth(object_name)
    else:
        _message('WARNING', 'DSSP data loaded, but no protein object is available for mapping')


def sweet_load_md(gro_path, xtc_path, dssp_path, object_name='', stride='1', max_frames='100'):
    """Load GRO/XTC plus frame-wise ``gmx dssp`` data as an interactive movie.

    ``stride`` samples both DSSP rows and XTC frames. The default cap of 100
    protects PyMOL from loading an unreasonably large trajectory by accident.
    """
    global DATASET, SOURCE, OBJECT, MD_DSSP_FRAMES, MD_STRIDE
    paths = [os.path.abspath(os.path.expanduser(str(value).strip().strip('"').strip("'")))
             for value in (gro_path, xtc_path, dssp_path)]
    gro_path, xtc_path, dssp_path = paths
    try:
        stride, max_frames = int(stride), int(max_frames)
        if stride < 1 or max_frames < 1:
            raise ValueError('stride and max_frames must be positive integers')
        if not gro_path.lower().endswith('.gro') or not xtc_path.lower().endswith('.xtc'):
            raise ValueError('expected .gro topology and .xtc trajectory')
        if any(not os.path.isfile(path) for path in paths):
            raise ValueError('GRO, XTC, or DSSP .dat file does not exist')
        object_name = str(object_name).strip().strip('"').strip("'") or re.sub(
            r'[^A-Za-z0-9_]+', '_', os.path.splitext(os.path.basename(gro_path))[0])
        if object_name in cmd.get_names('objects'):
            raise ValueError('PyMOL object already exists: ' + object_name)
        cmd.load(gro_path, object_name)
        records, all_frames = _read_gmx_dssp(dssp_path, object_name)
        sampled = all_frames[::stride][:max_frames]
        cmd.load_traj(xtc_path, object_name, state=1, interval=stride, max=len(sampled), quiet=1)
        state_count = cmd.count_states(object_name)
        sampled = sampled[:state_count]
        if not sampled:
            raise ValueError('no trajectory states were loaded')
    except Exception as error:
        _message('ERROR', 'could not load MD DSSP movie: %s' % error)
        return
    DATASET = records
    SOURCE = dssp_path
    OBJECT = object_name
    MD_DSSP_FRAMES = sampled; MD_STRIDE = stride
    _map_active(False); _render()
    try:
        _configure_md_movie()
    except Exception as error:
        _message('ERROR', 'trajectory loaded, but frame DSSP movie setup failed: %s' % error)


def sweet_load_md_pdb(trajectory_pdb, dssp_path, object_name='', stride='1', max_frames='100'):
    """Load a GROMACS-exported multi-model protein PDB and frame-wise DSSP.

    This is the robust route for PyMOL builds whose native XTC plugin is
    unstable. Make the PDB with ``gmx trjconv`` using the Protein group and a
    sampling interval matching ``stride`` in the full DSSP file.
    """
    global DATASET, SOURCE, OBJECT, MD_DSSP_FRAMES, MD_STRIDE
    paths = [os.path.abspath(os.path.expanduser(str(value).strip().strip('"').strip("'")))
             for value in (trajectory_pdb, dssp_path)]
    trajectory_pdb, dssp_path = paths
    try:
        stride, max_frames = int(stride), int(max_frames)
        if stride < 1 or max_frames < 1:
            raise ValueError('stride and max_frames must be positive integers')
        if not trajectory_pdb.lower().endswith(('.pdb', '.ent')):
            raise ValueError('expected a multi-model .pdb trajectory')
        if any(not os.path.isfile(path) for path in paths):
            raise ValueError('PDB trajectory or DSSP .dat file does not exist')
        object_name = str(object_name).strip().strip('"').strip("'") or re.sub(
            r'[^A-Za-z0-9_]+', '_', os.path.splitext(os.path.basename(trajectory_pdb))[0])
        if object_name in cmd.get_names('objects'):
            raise ValueError('PyMOL object already exists: ' + object_name)
        cmd.load(trajectory_pdb, object_name)
        records, all_frames = _read_gmx_dssp(dssp_path, object_name)
        sampled = all_frames[::stride][:max_frames]
        state_count = cmd.count_states(object_name)
        if state_count != len(sampled):
            raise ValueError('PDB has %d states but DSSP sampling selected %d rows; adjust stride/max_frames' %
                             (state_count, len(sampled)))
    except Exception as error:
        _message('ERROR', 'could not load PDB MD DSSP movie: %s' % error)
        return
    DATASET = records
    SOURCE = dssp_path
    OBJECT = object_name
    MD_DSSP_FRAMES = sampled; MD_STRIDE = stride
    _map_active(False); _render()
    try:
        _configure_md_movie()
    except Exception as error:
        _message('ERROR', 'PDB trajectory loaded, but frame DSSP movie setup failed: %s' % error)


def sweettooth(object_name, force='0'):
    """Map loaded DSSP data to a PyMOL object and create an interactive overlay."""
    global OBJECT
    if not DATASET:
        _message('ERROR', 'no DSSP data loaded; run sweettooth_load first')
        return
    if object_name not in cmd.get_names('objects'):
        _message('ERROR', 'PyMOL object not found: ' + object_name)
        return
    OBJECT = object_name
    _map_active(str(force).lower() in ('1', 'true', 'yes', 'on'))
    _render()



def sweettooth_residue(chain, residue=None):
    if residue is None:
        residue = chain
        chain = None
    matches = [record for record in MAPPED
               if record['resi'] == int(residue) and (chain is None or record['chain'] == chain)]
    if not matches:
        _message('WARNING', 'mapped residue not found')
        return
    record = matches[0]
    state = record['state']
    _message('INFO', 'DSSP %s:%d%s %s; state=%s (%s); source=%s' %
             (record['chain'], record['resi'], record['icode'], record['aa'],
              state, STATE_NAMES[state], SOURCE))



def sweettooth_status():
    _message('INFO', 'object=%s mapped=%d dssp=%d md_frames=%d' %
             (OBJECT or 'none', len(MAPPED), len(DATASET), len(MD_DSSP_FRAMES)))



def sweettooth_reset():
    global MD_DSSP_FRAMES
    cmd.delete(PREFIX + '*')
    MD_DSSP_FRAMES = []
    if OBJECT:
        cmd.show('cartoon', OBJECT)
    _message('INFO', 'removed SweetTooth Final objects only; source object restored')


for command, function in (
    ('sweet_load', sweet_load), ('sweettooth_load', sweettooth_load), ('sweettooth', sweettooth),
    ('sweet_load_md', sweet_load_md), ('sweet_load_md_pdb', sweet_load_md_pdb),
    ('sweettooth_residue', sweettooth_residue), ('sweettooth_status', sweettooth_status),
    ('sweettooth_reset', sweettooth_reset)):
    cmd.extend(command, function)


def __init_plugin__(app=None):
    """Entry point used by PyMOL's Plugin Manager."""
    cmd.bg_color('white')
    _message('INFO', 'Plugin Manager initialized SweetTooth Final commands')


cmd.bg_color('white')
_message('INFO', 'plugin loaded; commands registered; no data or images generated')
